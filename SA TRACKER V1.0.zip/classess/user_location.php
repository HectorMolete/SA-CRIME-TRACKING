
<script>
var vx = document.getElementById("latitude");
var vy = document.getElementById("longitude");
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  vx.value =position.coords.latitude ; 
  vy.value =position.coords.longitude ; 
  
 
}

getLocation();

</script>