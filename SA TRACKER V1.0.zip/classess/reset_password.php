<?php
  include("../database/connection.php");
  if($_GET['email']){
	  
	  $id_num=$_GET['id_number'];
	  $email=$_GET['email'];
	  
	  $sql="select * from user where email_address='$email' and id_number='$id_num'";
	  $results=mysqli_query($conn,$sql);
	  
	  if(mysqli_num_rows($results)>0){
		  
		   echo "<script>cxDialog('Reset Link sent. Please Check your Email Address');</script>"; 
		  
		  
	  }else{
		  
		  echo "<script>cxDialog('User Details not found');</script>"; 
		  
	  }
	  
  }



?>