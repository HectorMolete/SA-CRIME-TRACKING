<?php
  include("../database/connection.php");
  if(isset($_GET['officer_id'])){
	
  //Fetch all inputs data from officer Registeration form	
  $officer_id=$_GET['officer_id'];
  $email=$_GET['email'];
  $first_name=$_GET['first_name'];
  $last_name=$_GET['last_name'];
  $phone_number=$_GET['phone_number'];
  $address=$_GET['address'];
  $province=$_GET['province'];
  $password=$_GET['password'];
  $full_names=$last_name." ".$first_name;
  $station_id=$_GET['station_id'];
  
  //Encrypting Password before inserting to a Database
  $encypass=md5($password);
  
  //Insert Registeration Details inside the database
  $sql="insert into officer(officer_no,full_names,province,home_address,email,phone_number,password,station_id) values('$officer_id','$full_names','$province','$address','$email','$phone_number','$encypass','$station_id')";
  if(mysqli_query($conn,$sql)){
	  //Display a Success Meesgae
	  echo "<script>cxDialog('Successfully Registerec');</script>";
  }
  else{
	  
	 //Display Error Message if something went wrong
	 echo "<script>cxDialog('Failed <br>Something went wrong');</script>"; 
  }
  }
  
  

  
?>