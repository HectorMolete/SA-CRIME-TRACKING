
<?php
  
    if(!$_SESSION['user']){

		
         header('LOCATION:../index.php');
	}

?>